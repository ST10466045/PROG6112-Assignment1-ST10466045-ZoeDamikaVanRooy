package library;

public class Book extends Item {
    private String author;

    public Book(String title, String id, String author) {
        super(title, id);
        this.author = author;
    }

    public String getAuthor() { return author; }

    @Override
    public String toString() {
        return "Book ID: " + getId() + " | Title: " + getTitle() + " | Author: " + author;
    }
}
