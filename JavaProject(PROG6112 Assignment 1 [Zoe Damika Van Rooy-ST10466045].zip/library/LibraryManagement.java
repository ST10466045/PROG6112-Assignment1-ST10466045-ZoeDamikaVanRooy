package library;
import java.util.Scanner;

public class LibraryManagement {
    private static Book[] books = new Book[100];
    private static int bookCount = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            displayMenu();
            choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1 -> addBook();
                case 2 -> searchBook();
                case 3 -> deleteBook();
                case 4 -> displayReport();
                case 0 -> System.out.println("Exiting... Goodbye!");
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);
    }

    private static void displayMenu() {
        System.out.println("\n===== LIBRARY MANAGEMENT MENU =====");
        System.out.println("1. Add Book");
        System.out.println("2. Search Book");
        System.out.println("3. Delete Book");
        System.out.println("4. Display Report");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addBook() {
        System.out.print("Enter Book ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Author: ");
        String author = scanner.nextLine();

        books[bookCount++] = new Book(title, id, author);
        System.out.println("Book added successfully!");
    }

    private static void searchBook() {
        System.out.print("Enter Book ID to search: ");
        String searchId = scanner.nextLine();
        boolean found = false;

        for (int i = 0; i < bookCount; i++) {
            if (books[i].getId().equalsIgnoreCase(searchId)) {
                System.out.println("Book Found: " + books[i]);
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Book not found!");
    }

    private static void deleteBook() {
        System.out.print("Enter Book ID to delete: ");
        String deleteId = scanner.nextLine();
        boolean deleted = false;

        for (int i = 0; i < bookCount; i++) {
            if (books[i].getId().equalsIgnoreCase(deleteId)) {
                for (int j = i; j < bookCount - 1; j++) {
                    books[j] = books[j + 1];
                }
                books[--bookCount] = null;
                System.out.println("Book deleted successfully!");
                deleted = true;
                break;
            }
        }
        if (!deleted) System.out.println("Book not found for deletion.");
    }

    private static void displayReport() {
        System.out.println("\n===== LIBRARY REPORT =====");
        if (bookCount == 0) {
            System.out.println("No books available.");
        } else {
            for (int i = 0; i < bookCount; i++) {
                System.out.println((i + 1) + ". " + books[i]);
            }
        }
    }
}
