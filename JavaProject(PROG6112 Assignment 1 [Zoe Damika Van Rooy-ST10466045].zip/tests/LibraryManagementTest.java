import static org.junit.Assert.*;
import org.junit.Test;
import library.Book;

public class LibraryManagementTest {
    @Test
    public void testAddBook() {
        Book book = new Book("Java Basics", "B001", "John Doe");
        assertEquals("Java Basics", book.getTitle());
        assertEquals("B001", book.getId());
        assertEquals("John Doe", book.getAuthor());
    }

    @Test
    public void testToString() {
        Book book = new Book("Java Basics", "B001", "John Doe");
        assertTrue(book.toString().contains("Java Basics"));
    }
}
