package tvseries;
import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    private ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void CaptureSeries() {
        System.out.println("\n--- Capture New Series ---");

        System.out.print("Enter Series ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Series Name: ");
        String name = scanner.nextLine();

        String age;
        while (true) {
            System.out.print("Enter Age Restriction (2–18): ");
            age = scanner.nextLine();
            if (!age.matches("\\d+")) {
                System.out.println("Invalid input! Please enter a number.");
                continue;
            }
            int ageNum = Integer.parseInt(age);
            if (ageNum >= 2 && ageNum <= 18) break;
            else System.out.println("Age must be between 2 and 18.");
        }

        System.out.print("Enter Number of Episodes: ");
        String episodes = scanner.nextLine();

        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("✅ Series successfully saved!");
    }

    public void SearchSeries() {
        System.out.println("\n--- Search Series ---");
        System.out.print("Enter Series ID to search: ");
        String id = scanner.nextLine();

        SeriesModel found = findSeriesById(id);
        if (found != null) displaySeries(found);
        else System.out.println("❌ No series found with ID: " + id);
    }

    public void UpdateSeries() {
        System.out.println("\n--- Update Series ---");
        System.out.print("Enter Series ID to update: ");
        String id = scanner.nextLine();

        SeriesModel found = findSeriesById(id);
        if (found != null) {
            System.out.print("Enter New Name (current: " + found.SeriesName + "): ");
            found.SeriesName = scanner.nextLine();

            String age;
            while (true) {
                System.out.print("Enter New Age Restriction (2–18): ");
                age = scanner.nextLine();
                if (!age.matches("\\d+")) {
                    System.out.println("Invalid input! Please enter a number.");
                    continue;
                }
                int ageNum = Integer.parseInt(age);
                if (ageNum >= 2 && ageNum <= 18) break;
                else System.out.println("Age must be between 2 and 18.");
            }
            found.SeriesAge = age;

            System.out.print("Enter New Number of Episodes: ");
            found.SeriesNumberOfEpisodes = scanner.nextLine();

            System.out.println("✅ Series updated successfully!");
        } else {
            System.out.println("❌ No series found with ID: " + id);
        }
    }

    public void DeleteSeries() {
        System.out.println("\n--- Delete Series ---");
        System.out.print("Enter Series ID to delete: ");
        String id = scanner.nextLine();

        SeriesModel found = findSeriesById(id);
        if (found != null) {
            System.out.print("Are you sure you want to delete this series? (Y/N): ");
            String confirm = scanner.nextLine().trim().toUpperCase();
            if (confirm.equals("Y")) {
                seriesList.remove(found);
                System.out.println("✅ Series deleted successfully!");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } else {
            System.out.println("❌ No series found with ID: " + id);
        }
    }

    public void SeriesReport() {
        System.out.println("\n--- Series Report ---");
        if (seriesList.isEmpty()) {
            System.out.println("No series to display.");
            return;
        }
        for (SeriesModel s : seriesList) {
            displaySeries(s);
            System.out.println("----------------------------");
        }
    }

    public void ExitSeriesApplication() {
        System.out.println("👋 Exiting application... Goodbye!");
        System.exit(0);
    }

    private SeriesModel findSeriesById(String id) {
        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equalsIgnoreCase(id)) return s;
        }
        return null;
    }

    private void displaySeries(SeriesModel s) {
        System.out.println("Series ID: " + s.SeriesId);
        System.out.println("Name: " + s.SeriesName);
        System.out.println("Age Restriction: " + s.SeriesAge);
        System.out.println("Number of Episodes: " + s.SeriesNumberOfEpisodes);
    }
}
